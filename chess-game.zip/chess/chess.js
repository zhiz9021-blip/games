// 国际象棋游戏逻辑

const PIECES = {
    WHITE_KING: '♔', WHITE_QUEEN: '♕', WHITE_ROOK: '♖',
    WHITE_BISHOP: '♗', WHITE_KNIGHT: '♘', WHITE_PAWN: '♙',
    BLACK_KING: '♚', BLACK_QUEEN: '♛', BLACK_ROOK: '♜',
    BLACK_BISHOP: '♝', BLACK_KNIGHT: '♞', BLACK_PAWN: '♟'
};

const INITIAL_BOARD = [
    ['♜', '♞', '♝', '♛', '♚', '♝', '♞', '♜'],
    ['♟', '♟', '♟', '♟', '♟', '♟', '♟', '♟'],
    ['', '', '', '', '', '', '', ''],
    ['', '', '', '', '', '', '', ''],
    ['', '', '', '', '', '', '', ''],
    ['', '', '', '', '', '', '', ''],
    ['♙', '♙', '♙', '♙', '♙', '♙', '♙', '♙'],
    ['♖', '♘', '♗', '♕', '♔', '♗', '♘', '♖']
];

let board = [];
let currentPlayer = 'white';
let selectedSquare = null;
let validMoves = [];
let moveHistory = [];
let capturedByWhite = [];
let capturedByBlack = [];
let boardFlipped = false;
let castlingRights = {
    white: { kingSide: true, queenSide: true },
    black: { kingSide: true, queenSide: true }
};
let enPassantTarget = null;
let gameOver = false;

function initBoard() {
    board = INITIAL_BOARD.map(row => [...row]);
    currentPlayer = 'white';
    selectedSquare = null;
    validMoves = [];
    moveHistory = [];
    capturedByWhite = [];
    capturedByBlack = [];
    castlingRights = {
        white: { kingSide: true, queenSide: true },
        black: { kingSide: true, queenSide: true }
    };
    enPassantTarget = null;
    gameOver = false;
    renderBoard();
    updateInfo();
}

function getPieceColor(piece) {
    if (!piece) return null;
    return isWhitePiece(piece) ? 'white' : 'black';
}

function isWhitePiece(piece) {
    return '♔♕♖♗♘♙'.includes(piece);
}

function isBlackPiece(piece) {
    return '♚♛♜♝♞♟'.includes(piece);
}

function renderBoard() {
    const boardEl = document.getElementById('board');
    boardEl.innerHTML = '';

    for (let row = 0; row < 8; row++) {
        for (let col = 0; col < 8; col++) {
            const actualRow = boardFlipped ? 7 - row : row;
            const actualCol = boardFlipped ? 7 - col : col;
            
            const square = document.createElement('div');
            square.className = `square ${(actualRow + actualCol) % 2 === 0 ? 'light' : 'dark'}`;
            square.dataset.row = actualRow;
            square.dataset.col = actualCol;
            
            if (board[actualRow][actualCol]) {
                square.textContent = board[actualRow][actualCol];
            }
            
            if (selectedSquare && selectedSquare.row === actualRow && selectedSquare.col === actualCol) {
                square.classList.add('selected');
            }
            
            const validMove = validMoves.find(m => m.row === actualRow && m.col === actualCol);
            if (validMove) {
                square.classList.add('valid-move');
                if (board[actualRow][actualCol] || (enPassantTarget && enPassantTarget.row === actualRow && enPassantTarget.col === actualCol)) {
                    square.classList.add('capture');
                }
            }
            
            // 标记最后一步
            if (moveHistory.length > 0) {
                const lastMove = moveHistory[moveHistory.length - 1];
                if ((lastMove.from.row === actualRow && lastMove.from.col === actualCol) ||
                    (lastMove.to.row === actualRow && lastMove.to.col === actualCol)) {
                    square.classList.add('last-move');
                }
            }
            
            // 标记将军
            const kingPos = findKing(currentPlayer);
            if (kingPos && kingPos.row === actualRow && kingPos.col === actualCol && isInCheck(currentPlayer)) {
                square.classList.add('check');
            }
            
            square.addEventListener('click', () => handleSquareClick(actualRow, actualCol));
            boardEl.appendChild(square);
        }
    }
}

function handleSquareClick(row, col) {
    if (gameOver) return;
    
    const piece = board[row][col];
    const pieceColor = getPieceColor(piece);
    
    if (selectedSquare) {
        const validMove = validMoves.find(m => m.row === row && m.col === col);
        
        if (validMove) {
            makeMove(selectedSquare, { row, col });
            selectedSquare = null;
            validMoves = [];
        } else if (pieceColor === currentPlayer) {
            selectedSquare = { row, col };
            validMoves = getValidMoves(row, col);
        } else {
            selectedSquare = null;
            validMoves = [];
        }
    } else if (pieceColor === currentPlayer) {
        selectedSquare = { row, col };
        validMoves = getValidMoves(row, col);
    }
    
    renderBoard();
}

function getValidMoves(row, col) {
    const piece = board[row][col];
    if (!piece) return [];
    
    const moves = [];
    const color = getPieceColor(piece);
    
    switch (piece) {
        case '♙': case '♟':
            getPawnMoves(row, col, color, moves);
            break;
        case '♖': case '♜':
            getRookMoves(row, col, color, moves);
            break;
        case '♘': case '♞':
            getKnightMoves(row, col, color, moves);
            break;
        case '♗': case '♝':
            getBishopMoves(row, col, color, moves);
            break;
        case '♕': case '♛':
            getQueenMoves(row, col, color, moves);
            break;
        case '♔': case '♚':
            getKingMoves(row, col, color, moves);
            break;
    }
    
    // 过滤掉会导致自己被将军的走法
    return moves.filter(move => !wouldBeInCheck(row, col, move.row, move.col, color));
}

function getPawnMoves(row, col, color, moves) {
    const direction = color === 'white' ? -1 : 1;
    const startRow = color === 'white' ? 6 : 1;
    
    // 前进一格
    if (isValidSquare(row + direction, col) && !board[row + direction][col]) {
        moves.push({ row: row + direction, col });
        
        // 前进两格
        if (row === startRow && !board[row + 2 * direction][col]) {
            moves.push({ row: row + 2 * direction, col });
        }
    }
    
    // 吃子
    for (const dc of [-1, 1]) {
        const newRow = row + direction;
        const newCol = col + dc;
        if (isValidSquare(newRow, newCol)) {
            const targetPiece = board[newRow][newCol];
            if (targetPiece && getPieceColor(targetPiece) !== color) {
                moves.push({ row: newRow, col: newCol });
            }
            
            // 吃过路兵
            if (enPassantTarget && enPassantTarget.row === newRow && enPassantTarget.col === newCol) {
                moves.push({ row: newRow, col: newCol, enPassant: true });
            }
        }
    }
}

function getRookMoves(row, col, color, moves) {
    const directions = [[0, 1], [0, -1], [1, 0], [-1, 0]];
    getSlidingMoves(row, col, color, moves, directions);
}

function getBishopMoves(row, col, color, moves) {
    const directions = [[1, 1], [1, -1], [-1, 1], [-1, -1]];
    getSlidingMoves(row, col, color, moves, directions);
}

function getQueenMoves(row, col, color, moves) {
    const directions = [[0, 1], [0, -1], [1, 0], [-1, 0], [1, 1], [1, -1], [-1, 1], [-1, -1]];
    getSlidingMoves(row, col, color, moves, directions);
}

function getSlidingMoves(row, col, color, moves, directions) {
    for (const [dr, dc] of directions) {
        let newRow = row + dr;
        let newCol = col + dc;
        
        while (isValidSquare(newRow, newCol)) {
            const targetPiece = board[newRow][newCol];
            if (!targetPiece) {
                moves.push({ row: newRow, col: newCol });
            } else {
                if (getPieceColor(targetPiece) !== color) {
                    moves.push({ row: newRow, col: newCol });
                }
                break;
            }
            newRow += dr;
            newCol += dc;
        }
    }
}

function getKnightMoves(row, col, color, moves) {
    const offsets = [
        [-2, -1], [-2, 1], [-1, -2], [-1, 2],
        [1, -2], [1, 2], [2, -1], [2, 1]
    ];
    
    for (const [dr, dc] of offsets) {
        const newRow = row + dr;
        const newCol = col + dc;
        if (isValidSquare(newRow, newCol)) {
            const targetPiece = board[newRow][newCol];
            if (!targetPiece || getPieceColor(targetPiece) !== color) {
                moves.push({ row: newRow, col: newCol });
            }
        }
    }
}

function getKingMoves(row, col, color, moves) {
    const offsets = [
        [-1, -1], [-1, 0], [-1, 1],
        [0, -1], [0, 1],
        [1, -1], [1, 0], [1, 1]
    ];
    
    for (const [dr, dc] of offsets) {
        const newRow = row + dr;
        const newCol = col + dc;
        if (isValidSquare(newRow, newCol)) {
            const targetPiece = board[newRow][newCol];
            if (!targetPiece || getPieceColor(targetPiece) !== color) {
                moves.push({ row: newRow, col: newCol });
            }
        }
    }
    
    // 王车易位
    if (!isInCheck(color)) {
        const rights = castlingRights[color];
        const kingRow = color === 'white' ? 7 : 0;
        
        if (row === kingRow && col === 4) {
            // 王侧易位
            if (rights.kingSide && !board[kingRow][5] && !board[kingRow][6]) {
                if (!wouldBeInCheck(row, col, kingRow, 5, color) && 
                    !wouldBeInCheck(row, col, kingRow, 6, color)) {
                    moves.push({ row: kingRow, col: 6, castling: 'kingSide' });
                }
            }
            // 后侧易位
            if (rights.queenSide && !board[kingRow][3] && !board[kingRow][2] && !board[kingRow][1]) {
                if (!wouldBeInCheck(row, col, kingRow, 3, color) && 
                    !wouldBeInCheck(row, col, kingRow, 2, color)) {
                    moves.push({ row: kingRow, col: 2, castling: 'queenSide' });
                }
            }
        }
    }
}

function isValidSquare(row, col) {
    return row >= 0 && row < 8 && col >= 0 && col < 8;
}

function makeMove(from, to) {
    const piece = board[from.row][from.col];
    const targetPiece = board[to.row][to.col];
    const color = getPieceColor(piece);
    const validMove = validMoves.find(m => m.row === to.row && m.col === to.col);
    
    // 记录移动历史
    moveHistory.push({
        from: { ...from },
        to: { ...to },
        piece,
        captured: targetPiece,
        enPassant: validMove?.enPassant,
        castling: validMove?.castling,
        promotion: validMove?.promotion
    });
    
    // 处理吃子
    if (targetPiece) {
        if (color === 'white') {
            capturedByWhite.push(targetPiece);
        } else {
            capturedByBlack.push(targetPiece);
        }
    }
    
    // 处理吃过路兵
    if (validMove?.enPassant) {
        const capturedPawnRow = from.row;
        const capturedPawn = board[capturedPawnRow][to.col];
        if (color === 'white') {
            capturedByWhite.push(capturedPawn);
        } else {
            capturedByBlack.push(capturedPawn);
        }
        board[capturedPawnRow][to.col] = '';
    }
    
    // 处理王车易位
    if (validMove?.castling) {
        const kingRow = from.row;
        if (validMove.castling === 'kingSide') {
            board[kingRow][5] = board[kingRow][7];
            board[kingRow][7] = '';
        } else if (validMove.castling === 'queenSide') {
            board[kingRow][3] = board[kingRow][0];
            board[kingRow][0] = '';
        }
    }
    
    // 移动棋子
    board[to.row][to.col] = piece;
    board[from.row][from.col] = '';
    
    // 处理兵升变
    if ((piece === '♙' && to.row === 0) || (piece === '♟' && to.row === 7)) {
        board[to.row][to.col] = color === 'white' ? '♕' : '♛';
    }
    
    // 更新王车易位权利
    if (piece === '♔') {
        castlingRights.white.kingSide = false;
        castlingRights.white.queenSide = false;
    } else if (piece === '♚') {
        castlingRights.black.kingSide = false;
        castlingRights.black.queenSide = false;
    } else if (piece === '♖') {
        if (from.col === 0) castlingRights.white.queenSide = false;
        if (from.col === 7) castlingRights.white.kingSide = false;
    } else if (piece === '♜') {
        if (from.col === 0) castlingRights.black.queenSide = false;
        if (from.col === 7) castlingRights.black.kingSide = false;
    }
    
    // 更新过路兵目标
    if ((piece === '♙' || piece === '♟') && Math.abs(to.row - from.row) === 2) {
        enPassantTarget = { row: (from.row + to.row) / 2, col: from.col };
    } else {
        enPassantTarget = null;
    }
    
    // 切换玩家
    currentPlayer = currentPlayer === 'white' ? 'black' : 'white';
    
    // 检查游戏结束
    checkGameOver();
    
    updateInfo();
    renderBoard();
}

function wouldBeInCheck(fromRow, fromCol, toRow, toCol, color) {
    // 临时执行移动
    const piece = board[fromRow][fromCol];
    const targetPiece = board[toRow][toCol];
    
    board[toRow][toCol] = piece;
    board[fromRow][fromCol] = '';
    
    const inCheck = isInCheck(color);
    
    // 恢复
    board[fromRow][fromCol] = piece;
    board[toRow][toCol] = targetPiece;
    
    return inCheck;
}

function isInCheck(color) {
    const kingPos = findKing(color);
    if (!kingPos) return false;
    
    const opponentColor = color === 'white' ? 'black' : 'white';
    
    for (let row = 0; row < 8; row++) {
        for (let col = 0; col < 8; col++) {
            const piece = board[row][col];
            if (piece && getPieceColor(piece) === opponentColor) {
                const moves = getBasicMoves(row, col);
                if (moves.some(m => m.row === kingPos.row && m.col === kingPos.col)) {
                    return true;
                }
            }
        }
    }
    
    return false;
}

function findKing(color) {
    const king = color === 'white' ? '♔' : '♚';
    for (let row = 0; row < 8; row++) {
        for (let col = 0; col < 8; col++) {
            if (board[row][col] === king) {
                return { row, col };
            }
        }
    }
    return null;
}

function getBasicMoves(row, col) {
    const piece = board[row][col];
    if (!piece) return [];
    
    const moves = [];
    const color = getPieceColor(piece);
    
    switch (piece) {
        case '♙': case '♟':
            getPawnMoves(row, col, color, moves);
            break;
        case '♖': case '♜':
            getRookMoves(row, col, color, moves);
            break;
        case '♘': case '♞':
            getKnightMoves(row, col, color, moves);
            break;
        case '♗': case '♝':
            getBishopMoves(row, col, color, moves);
            break;
        case '♕': case '♛':
            getQueenMoves(row, col, color, moves);
            break;
        case '♔': case '♚':
            getKingMoves(row, col, color, moves);
            break;
    }
    
    return moves;
}

function checkGameOver() {
    // 检查是否有合法移动
    let hasLegalMoves = false;
    
    for (let row = 0; row < 8; row++) {
        for (let col = 0; col < 8; col++) {
            const piece = board[row][col];
            if (piece && getPieceColor(piece) === currentPlayer) {
                const moves = getValidMoves(row, col);
                if (moves.length > 0) {
                    hasLegalMoves = true;
                    break;
                }
            }
        }
        if (hasLegalMoves) break;
    }
    
    if (!hasLegalMoves) {
        gameOver = true;
        const statusEl = document.getElementById('status');
        if (isInCheck(currentPlayer)) {
            const winner = currentPlayer === 'white' ? '黑方' : '白方';
            statusEl.textContent = `将死！${winner}获胜！`;
        } else {
            statusEl.textContent = '逼和（无子可动）！';
        }
    }
}

function updateInfo() {
    const playerEl = document.getElementById('playerIndicator');
    const statusEl = document.getElementById('status');
    
    if (!gameOver) {
        playerEl.textContent = currentPlayer === 'white' ? '⚪ 白方' : '⚫ 黑方';
        playerEl.className = currentPlayer === 'white' ? 'white' : 'black';
        
        if (isInCheck(currentPlayer)) {
            statusEl.textContent = '将军！';
        } else {
            statusEl.textContent = '';
        }
    }
    
    // 更新被吃棋子
    document.getElementById('whiteCaptured').innerHTML = capturedByWhite.join(' ');
    document.getElementById('blackCaptured').innerHTML = capturedByBlack.join(' ');
    
    // 更新走棋历史
    const historyEl = document.getElementById('moveHistory');
    historyEl.innerHTML = moveHistory.map((move, i) => {
        const moveNum = Math.floor(i / 2) + 1;
        const notation = getMoveNotation(move);
        if (i % 2 === 0) {
            return `<div class="move-item">${moveNum}. ${notation}</div>`;
        } else {
            return `<div class="move-item">${notation}</div>`;
        }
    }).join('');
}

function getMoveNotation(move) {
    const cols = 'abcdefgh';
    const rows = '87654321';
    
    if (move.castling === 'kingSide') return 'O-O';
    if (move.castling === 'queenSide') return 'O-O-O';
    
    let notation = '';
    if (move.piece !== '♙' && move.piece !== '♟') {
        const pieceLetters = { '♖': 'R', '♘': 'N', '♗': 'B', '♕': 'Q', '♔': 'K' };
        notation += pieceLetters[move.piece] || '';
    }
    
    if (move.captured || move.enPassant) {
        if (!notation) notation = cols[move.from.col];
        notation += 'x';
    }
    
    notation += cols[move.to.col] + rows[move.to.row];
    
    return notation;
}

function newGame() {
    initBoard();
}

function undoMove() {
    if (moveHistory.length === 0) return;
    
    const lastMove = moveHistory.pop();
    
    // 恢复棋子
    board[lastMove.from.row][lastMove.from.col] = lastMove.piece;
    board[lastMove.to.row][lastMove.to.col] = lastMove.captured || '';
    
    // 恢复吃过路兵的棋子
    if (lastMove.enPassant) {
        const capturedPawnRow = lastMove.from.row;
        board[capturedPawnRow][lastMove.to.col] = currentPlayer === 'white' ? '♟' : '♙';
        if (currentPlayer === 'white') {
            capturedByWhite.pop();
        } else {
            capturedByBlack.pop();
        }
    }
    
    // 恢复王车易位的车
    if (lastMove.castling) {
        const kingRow = lastMove.from.row;
        if (lastMove.castling === 'kingSide') {
            board[kingRow][7] = board[kingRow][5];
            board[kingRow][5] = '';
        } else if (lastMove.castling === 'queenSide') {
            board[kingRow][0] = board[kingRow][3];
            board[kingRow][3] = '';
        }
    }
    
    // 恢复被吃的棋子
    if (lastMove.captured) {
        if (currentPlayer === 'white') {
            capturedByWhite.pop();
        } else {
            capturedByBlack.pop();
        }
    }
    
    // 切换玩家
    currentPlayer = currentPlayer === 'white' ? 'black' : 'white';
    
    // 恢复王车易位权利
    if (lastMove.piece === '♔') {
        castlingRights.white.kingSide = true;
        castlingRights.white.queenSide = true;
    } else if (lastMove.piece === '♚') {
        castlingRights.black.kingSide = true;
        castlingRights.black.queenSide = true;
    } else if (lastMove.piece === '♖') {
        if (lastMove.from.col === 0) castlingRights.white.queenSide = true;
        if (lastMove.from.col === 7) castlingRights.white.kingSide = true;
    } else if (lastMove.piece === '♜') {
        if (lastMove.from.col === 0) castlingRights.black.queenSide = true;
        if (lastMove.from.col === 7) castlingRights.black.kingSide = true;
    }
    
    gameOver = false;
    selectedSquare = null;
    validMoves = [];
    
    updateInfo();
    renderBoard();
}

function flipBoard() {
    boardFlipped = !boardFlipped;
    renderBoard();
}

// 启动游戏
initBoard();
